package com.inventario.sistemainventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemainventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemainventarioApplication.class, args);
	}

}
