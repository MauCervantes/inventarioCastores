package com.inventario.sistemainventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemainventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
